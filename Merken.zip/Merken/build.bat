@echo off
setlocal

rem --- OUTPUT ---------------------------------------------------------
set OUT=Merken.exe
echo Building %OUT%

rem --- PATHS ----------------------------------------------------------
set MINGW=C:\mingw-w64
set WX=C:\wxWidgets
set PATH=%MINGW%\bin;%PATH%

rem --- INCLUDE / LIB PATHS -------------------------------------------
set INC=-I include -I %WX%\lib\gcc_lib\mswu -I %WX%\include
set LIB=-L %WX%\lib\gcc_lib

rem --- WXWIDGETS LIBS -------------------------------------------------
set WXLIBS= ^
    -lwxmsw32u_core ^
    -lwxbase32u ^
    -lwxpng ^
    -lwxjpeg ^
    -lwxzlib ^
    -lwxregexu ^
    -lwxexpat

rem --- WINDOWS SYSTEM LIBS -------------------------------------------
set WINLIBS= ^
    -lshlwapi ^
    -lversion ^
    -lole32 ^
    -lshell32 ^
    -luuid ^
    -luxtheme ^
    -lgdi32 ^
    -loleaut32 ^
    -lcomdlg32 ^
    -lcomctl32 ^
    -loleacc ^
    -lwinspool

rem --- MANIFEST -------------------------------------------------------
echo 1 24 src\app.manifest > src\manifest.rc
%MINGW%\bin\windres.exe src\manifest.rc -O coff -o obj\manifest.o

rem --- ENSURE OBJ FOLDER ----------------------------------------------
if not exist obj mkdir obj

rem --- COMPILE --------------------------------------------------------
echo Compiling sources...
for %%f in (src\*.cpp) do (
    echo %%f
    %MINGW%\bin\g++.exe -c %%f %INC% -o obj\%%~nf.o
)

rem --- LINK -----------------------------------------------------------
echo Linking...
%MINGW%\bin\g++.exe obj\*.o -o %OUT% ^
%LIB% %WXLIBS% %WINLIBS%

echo Build complete: %OUT%

endlocal
